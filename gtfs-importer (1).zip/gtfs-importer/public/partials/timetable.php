<div class="gtfs-timetable">
    <p>Timetable goes here. You can add dynamic AJAX or query logic.</p>
</div>
