<div class="gtfs-fare-calculator">
    <form>
        <label for="origin">Origin Stop ID:</label>
        <input type="text" name="origin" id="origin" />
        <label for="destination">Destination Stop ID:</label>
        <input type="text" name="destination" id="destination" />
        <button type="submit">Calculate Fare</button>
    </form>
</div>
