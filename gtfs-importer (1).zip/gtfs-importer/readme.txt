=== GTFS Importer ===
Contributors: your-name
Tags: gtfs, timetable, transit
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 1.0.0
License: GPLv2 or later

== Description ==
This plugin imports GTFS transit data into WordPress, providing interactive timetables and fare calculation.
